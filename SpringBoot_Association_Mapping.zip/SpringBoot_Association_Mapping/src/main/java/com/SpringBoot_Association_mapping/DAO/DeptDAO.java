package com.SpringBoot_Association_mapping.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.SpringBoot_Association_mapping.Entity.Dept;

@Repository
public class DeptDAO {

	@Autowired
	SessionFactory factory;

	public String insertData(Dept dept) {
		Session s = factory.openSession();
		Transaction tr = s.beginTransaction();

		s.persist(dept);

		tr.commit();
		s.close();

		return "Department Inserted Successfully!";
	}

	public String updateData(Dept dpt, int id) {
		Session s = factory.openSession();
		Transaction tr = s.beginTransaction();

		Dept d = s.get(Dept.class, id);
		d.setName(dpt.getName());

		tr.commit();
		s.close();

		return "Department Updated Successfully!";
	}
}