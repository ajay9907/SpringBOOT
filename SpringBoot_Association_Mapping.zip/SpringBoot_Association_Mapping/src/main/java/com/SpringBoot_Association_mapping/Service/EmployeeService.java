package com.SpringBoot_Association_mapping.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot_Association_mapping.DAO.EmployeeDAO;
import com.SpringBoot_Association_mapping.Entity.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDAO dao;

	public String insertData(Employee emp) {
		return dao.insertData(emp);
	}

	public String updateData(Employee emp, int id) {
		return dao.updateData(emp, id);
	}
}