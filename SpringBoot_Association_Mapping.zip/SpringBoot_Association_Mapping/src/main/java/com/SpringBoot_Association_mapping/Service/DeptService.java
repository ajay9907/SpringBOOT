package com.SpringBoot_Association_mapping.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBoot_Association_mapping.DAO.DeptDAO;
import com.SpringBoot_Association_mapping.Entity.Dept;

@Service
public class DeptService {

	@Autowired
	DeptDAO dao;

	public String insertData(Dept dept) {
		return dao.insertData(dept);
	}

	public String updateData(Dept dept, int id) {
		return dao.updateData(dept, id);
	}
}